/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conecet;
import java.sql.*;

/**
 *
 * @author haris28
 */
public class konek {
    Connection con;
     public konek(){
 try { 
     Class.forName("com.mysql.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Data?characterEncoding=utf8","root","0");
 }catch(Exception e) {
   System.err.print("koneksi gagal" + e);
 //JOptionPane.showMessageDialog(null, e);
    }
 }  

    public Connection getConnection() {
        return con;
    }
    public static void main (String[]aksi){
        konek kon = new konek();
    }
}

    